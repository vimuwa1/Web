import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import products from '../data/products';
import { useCart } from '../context/CartContext';
import styled from 'styled-components';

const ProductView = () => {
  const { id } = useParams();
  const product = products.find(p => p.id === parseInt(id));
  const { addToCart } = useCart();
  const [selectedColor, setSelectedColor] = useState(product.colors?.[0]);
  const [selectedSize, setSelectedSize] = useState(product.sizes?.[0]);
  const [quantity, setQuantity] = useState(1);

  if (!product) {
    return <NotFound>Product not found</NotFound>;
  }

  return (
    <ProductContainer
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <ProductGallery>
        <MainImage
          src={`${product.image}?w=800&h=800&auto=format&fit=crop`}
          alt={product.name}
          as={motion.img}
          whileHover={{ scale: 1.02 }}
        />
        <ThumbnailContainer>
          {[1, 2, 3].map((i) => (
            <Thumbnail
              key={i}
              src={`${product.image}?w=200&h=200&auto=format&fit=crop&${i}`}
              alt={`${product.name} view ${i}`}
            />
          ))}
        </ThumbnailContainer>
      </ProductGallery>
      
      <ProductDetails>
        <ProductHeader>
          <ProductTitle>{product.name}</ProductTitle>
          <ProductPrice>${product.price.toFixed(2)}</ProductPrice>
        </ProductHeader>
        
        <Rating>
          {[...Array(5)].map((_, i) => (
            <Star key={i} filled={i < Math.floor(product.rating)}>
              ★
            </Star>
          ))}
          <ReviewCount>({product.reviews} reviews)</ReviewCount>
        </Rating>
        
        <ProductDescription>{product.description}</ProductDescription>
        
        {product.colors && (
          <ColorSelector>
            <Label>Color:</Label>
            <ColorOptions>
              {product.colors.map(color => (
                <ColorOption
                  key={color}
                  color={color.toLowerCase()}
                  selected={color === selectedColor}
                  onClick={() => setSelectedColor(color)}
                />
              ))}
            </ColorOptions>
          </ColorSelector>
        )}
        
        {product.sizes && (
          <SizeSelector>
            <Label>Size:</Label>
            <SizeOptions>
              {product.sizes.map(size => (
                <SizeOption
                  key={size}
                  selected={size === selectedSize}
                  onClick={() => setSelectedSize(size)}
                >
                  {size}
                </SizeOption>
              ))}
            </SizeOptions>
          </SizeSelector>
        )}
        
        <QuantitySelector>
          <Label>Quantity:</Label>
          <QuantityControls>
            <QuantityButton onClick={() => setQuantity(q => Math.max(1, q - 1))}>
              -
            </QuantityButton>
            <QuantityDisplay>{quantity}</QuantityDisplay>
            <QuantityButton onClick={() => setQuantity(q => q + 1)}>
              +
            </QuantityButton>
          </QuantityControls>
        </QuantitySelector>
        
        <ButtonGroup>
          <AddToCartButton
            onClick={() => addToCart({ ...product, quantity })}
            as={motion.button}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
          >
            Add to Cart
          </AddToCartButton>
          <BuyNowButton
            as={motion.button}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
          >
            Buy Now
          </BuyNowButton>
        </ButtonGroup>
        
        {product.features && (
          <Features>
            <h3>Features</h3>
            <ul>
              {product.features.map((feature, i) => (
                <li key={i}>{feature}</li>
              ))}
            </ul>
          </Features>
        )}
      </ProductDetails>
    </ProductContainer>
  );
};

const ProductContainer = styled(motion.div)`
  display: flex;
  max-width: 1200px;
  margin: 2rem auto;
  padding: 0 1rem;
  gap: 2rem;
  
  @media (max-width: 768px) {
    flex-direction: column;
  }
`;

const ProductGallery = styled.div`
  flex: 1;
`;

const MainImage = styled.img`
  width: 100%;
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin-bottom: 1rem;
  cursor: zoom-in;
`;

const ThumbnailContainer = styled.div`
  display: flex;
  gap: 0.5rem;
`;

const Thumbnail = styled.img`
  width: 80px;
  height: 80px;
  border-radius: 0.25rem;
  cursor: pointer;
  border: 2px solid transparent;
  transition: all 0.2s ease;
  
  &:hover {
    border-color: #3b82f6;
  }
`;

const ProductDetails = styled.div`
  flex: 1;
  padding: 0 1rem;
`;

const ProductHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

const ProductTitle = styled.h1`
  font-size: 1.75rem;
  font-weight: 700;
`;

const ProductPrice = styled.div`
  font-size: 1.5rem;
  font-weight: 700;
  color: #3b82f6;
`;

const Rating = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 1.5rem;
`;

const Star = styled.span`
  color: ${props => props.filled ? '#f59e0b' : '#d1d5db'};
  font-size: 1.25rem;
`;

const ReviewCount = styled.span`
  color: #6b7280;
  font-size: 0.875rem;
  margin-left: 0.5rem;
`;

const ProductDescription = styled.p`
  color: #4b5563;
  margin-bottom: 2rem;
  line-height: 1.6;
`;

const ColorSelector = styled.div`
  margin-bottom: 1.5rem;
`;

const Label = styled.span`
  display: block;
  font-weight: 600;
  margin-bottom: 0.5rem;
`;

const ColorOptions = styled.div`
  display: flex;
  gap: 0.5rem;
`;

const ColorOption = styled.div`
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background-color: ${props => props.color};
  cursor: pointer;
  border: 2px solid ${props => props.selected ? '#3b82f6' : 'transparent'};
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const SizeSelector = styled.div`
  margin-bottom: 1.5rem;
`;

const SizeOptions = styled.div`
  display: flex;
  gap: 0.5rem;
`;

const SizeOption = styled.div`
  padding: 0.5rem 1rem;
  border: 1px solid ${props => props.selected ? '#3b82f6' : '#d1d5db'};
  border-radius: 0.25rem;
  cursor: pointer;
  background-color: ${props => props.selected ? '#eff6ff' : 'white'};
  color: ${props => props.selected ? '#3b82f6' : '#4b5563'};
  font-weight: ${props => props.selected ? '600' : 'normal'};
  
  &:hover {
    border-color: #3b82f6;
  }
`;

const QuantitySelector = styled.div`
  margin-bottom: 2rem;
`;

const QuantityControls = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const QuantityButton = styled.button`
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f3f4f6;
  border: none;
  border-radius: 0.25rem;
  font-size: 1.25rem;
  cursor: pointer;
  
  &:hover {
    background: #e5e7eb;
  }
`;

const QuantityDisplay = styled.span`
  width: 60px;
  text-align: center;
  font-size: 1rem;
  font-weight: 600;
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
`;

const AddToCartButton = styled.button`
  flex: 1;
  padding: 1rem;
  background: #3b82f6;
  color: white;
  border: none;
  border-radius: 0.5rem;
  font-weight: 600;
  cursor: pointer;
  
  &:hover {
    background: #2563eb;
  }
`;

const BuyNowButton = styled.button`
  flex: 1;
  padding: 1rem;
  background: #10b981;
  color: white;
  border: none;
  border-radius: 0.5rem;
  font-weight: 600;
  cursor: pointer;
  
  &:hover {
    background: #059669;
  }
`;

const Features = styled.div`
  h3 {
    font-size: 1.25rem;
    margin-bottom: 0.5rem;
  }
  
  ul {
    padding-left: 1.25rem;
    color: #4b5563;
    line-height: 1.6;
  }
  
  li {
    margin-bottom: 0.5rem;
  }
`;

const NotFound = styled.div`
  text-align: center;
  padding: 2rem;
  font-size: 1.5rem;
  color: #ef4444;
`;

export default ProductView;
import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import ProductGrid from '../components/ProductGrid';
import products from '../data/products';
import styled from 'styled-components';

const Products = () => {
  const [searchParams] = useSearchParams();
  const category = searchParams.get('category');
  const searchQuery = searchParams.get('search');
  
  const [sortOption, setSortOption] = useState('featured');
  
  // Filter products based on category or search query
  let filteredProducts = products;
  
  if (category) {
    filteredProducts = products.filter(product => 
      product.category.toLowerCase() === category.toLowerCase()
    );
  }
  
  if (searchQuery) {
    filteredProducts = products.filter(product =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }
  
  // Sort products based on selected option
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortOption) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'rating':
        return b.rating - a.rating;
      default:
        return 0;
    }
  });

  return (
    <ProductsContainer>
      <ProductsHeader>
        <h1>
          {category ? `${category} Products` : 
           searchQuery ? `Search Results for "${searchQuery}"` : 
           'All Products'}
        </h1>
        <SortContainer>
          <label>Sort by:</label>
          <SortSelect 
            value={sortOption} 
            onChange={(e) => setSortOption(e.target.value)}
          >
            <option value="featured">Featured</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="rating">Rating</option>
          </SortSelect>
        </SortContainer>
      </ProductsHeader>
      
      <ProductCount>{sortedProducts.length} products found</ProductCount>
      
      <ProductGrid products={sortedProducts} />
    </ProductsContainer>
  );
};

const ProductsContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem 1rem;
`;

const ProductsHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.5rem;
  
  h1 {
    font-size: 1.75rem;
    color: #1f2937;
  }
`;

const SortContainer = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
  
  label {
    color: #6b7280;
  }
`;

const SortSelect = styled.select`
  padding: 0.5rem;
  border: 1px solid #d1d5db;
  border-radius: 0.25rem;
  background: white;
`;

const ProductCount = styled.p`
  color: #6b7280;
  margin-bottom: 1.5rem;
`;

export default Products;
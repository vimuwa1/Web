import { useContext } from 'react';
import { useCart } from '../context/CartContext';
import styled from 'styled-components';

const Cart = () => {
  const { cartItems, cartTotal, removeFromCart, updateQuantity, clearCart } = useCart();

  return (
    <CartContainer>
      <h1>Your Shopping Cart</h1>
      
      {cartItems.length === 0 ? (
        <EmptyCart>
          <p>Your cart is empty</p>
          <ContinueShopping href="/products">Continue Shopping</ContinueShopping>
        </EmptyCart>
      ) : (
        <>
          <CartItems>
            {cartItems.map(item => (
              <CartItem key={item.id}>
                <ProductImage src={item.image} alt={item.name} />
                <ProductDetails>
                  <ProductName>{item.name}</ProductName>
                  <ProductPrice>${item.price.toFixed(2)}</ProductPrice>
                  <QuantityControl>
                    <QuantityButton onClick={() => updateQuantity(item.id, item.quantity - 1)}>
                      -
                    </QuantityButton>
                    <Quantity>{item.quantity}</Quantity>
                    <QuantityButton onClick={() => updateQuantity(item.id, item.quantity + 1)}>
                      +
                    </QuantityButton>
                  </QuantityControl>
                </ProductDetails>
                <RemoveButton onClick={() => removeFromCart(item.id)}>
                  Remove
                </RemoveButton>
              </CartItem>
            ))}
          </CartItems>
          
          <CartSummary>
            <SummaryRow>
              <span>Subtotal</span>
              <span>${cartTotal.toFixed(2)}</span>
            </SummaryRow>
            <SummaryRow>
              <span>Shipping</span>
              <span>Free</span>
            </SummaryRow>
            <SummaryRow total>
              <span>Total</span>
              <span>${cartTotal.toFixed(2)}</span>
            </SummaryRow>
            
            <CheckoutButton>Proceed to Checkout</CheckoutButton>
            <ClearCartButton onClick={clearCart}>Clear Cart</ClearCartButton>
          </CartSummary>
        </>
      )}
    </CartContainer>
  );
};

const CartContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem 1rem;
  
  h1 {
    font-size: 2rem;
    margin-bottom: 2rem;
    text-align: center;
  }
`;

const EmptyCart = styled.div`
  text-align: center;
  padding: 4rem 0;
  
  p {
    font-size: 1.25rem;
    color: #666;
    margin-bottom: 1rem;
  }
`;

const ContinueShopping = styled.a`
  display: inline-block;
  padding: 0.75rem 1.5rem;
  background: #3b82f6;
  color: white;
  border-radius: 0.25rem;
  text-decoration: none;
  font-weight: 600;
  
  &:hover {
    background: #2563eb;
  }
`;

const CartItems = styled.div`
  margin-bottom: 2rem;
`;

const CartItem = styled.div`
  display: flex;
  align-items: center;
  padding: 1rem;
  border-bottom: 1px solid #eee;
  gap: 1.5rem;
`;

const ProductImage = styled.img`
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 0.25rem;
`;

const ProductDetails = styled.div`
  flex-grow: 1;
`;

const ProductName = styled.h3`
  font-size: 1.1rem;
  margin-bottom: 0.5rem;
`;

const ProductPrice = styled.p`
  color: #666;
  margin-bottom: 0.5rem;
`;

const QuantityControl = styled.div`
  display: flex;
  align-items: center;
  gap: 0.5rem;
`;

const QuantityButton = styled.button`
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f3f4f6;
  border: none;
  border-radius: 0.25rem;
  cursor: pointer;
  
  &:hover {
    background: #e5e7eb;
  }
`;

const Quantity = styled.span`
  width: 40px;
  text-align: center;
`;

const RemoveButton = styled.button`
  padding: 0.5rem 1rem;
  background: #fef2f2;
  color: #ef4444;
  border: 1px solid #fecaca;
  border-radius: 0.25rem;
  cursor: pointer;
  
  &:hover {
    background: #fee2e2;
  }
`;

const CartSummary = styled.div`
  background: white;
  padding: 1.5rem;
  border-radius: 0.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  max-width: 400px;
  margin-left: auto;
`;

const SummaryRow = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 1rem;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid #eee;
  font-weight: ${props => props.total ? '600' : 'normal'};
  font-size: ${props => props.total ? '1.1rem' : '1rem'};
`;

const CheckoutButton = styled.button`
  width: 100%;
  padding: 1rem;
  background: #10b981;
  color: white;
  border: none;
  border-radius: 0.25rem;
  font-weight: 600;
  cursor: pointer;
  margin-top: 1rem;
  
  &:hover {
    background: #059669;
  }
`;

const ClearCartButton = styled.button`
  width: 100%;
  padding: 1rem;
  background: #f3f4f6;
  color: #666;
  border: none;
  border-radius: 0.25rem;
  font-weight: 600;
  cursor: pointer;
  margin-top: 0.5rem;
  
  &:hover {
    background: #e5e7eb;
  }
`;

export default Cart;
import { useState } from 'react';
import styled from 'styled-components';

const AdminPanel = () => {
  const [activeTab, setActiveTab] = useState('products');

  return (
    <AdminContainer>
      <AdminHeader>
        <h1>Admin Dashboard</h1>
      </AdminHeader>
      
      <AdminTabs>
        <TabButton 
          active={activeTab === 'products'} 
          onClick={() => setActiveTab('products')}
        >
          Products
        </TabButton>
        <TabButton 
          active={activeTab === 'orders'} 
          onClick={() => setActiveTab('orders')}
        >
          Orders
        </TabButton>
        <TabButton 
          active={activeTab === 'users'} 
          onClick={() => setActiveTab('users')}
        >
          Users
        </TabButton>
      </AdminTabs>
      
      <AdminContent>
        {activeTab === 'products' && <ProductsManagement />}
        {activeTab === 'orders' && <OrdersManagement />}
        {activeTab === 'users' && <UsersManagement />}
      </AdminContent>
    </AdminContainer>
  );
};

const ProductsManagement = () => (
  <div>
    <h2>Product Management</h2>
    <p>Add, edit, or remove products from your store</p>
    {/* Product management UI would go here */}
  </div>
);

const OrdersManagement = () => (
  <div>
    <h2>Order Management</h2>
    <p>View and process customer orders</p>
    {/* Order management UI would go here */}
  </div>
);

const UsersManagement = () => (
  <div>
    <h2>User Management</h2>
    <p>Manage customer accounts</p>
    {/* User management UI would go here */}
  </div>
);

const AdminContainer = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 2rem 1rem;
`;

const AdminHeader = styled.div`
  margin-bottom: 2rem;
  
  h1 {
    font-size: 2rem;
    color: #333;
  }
`;

const AdminTabs = styled.div`
  display: flex;
  border-bottom: 1px solid #ddd;
  margin-bottom: 2rem;
`;

const TabButton = styled.button`
  padding: 0.75rem 1.5rem;
  background: ${props => props.active ? '#3b82f6' : 'transparent'};
  color: ${props => props.active ? 'white' : '#666'};
  border: none;
  border-radius: 0.25rem 0.25rem 0 0;
  cursor: pointer;
  font-weight: 600;
  
  &:hover {
    background: ${props => props.active ? '#2563eb' : '#f3f4f6'};
  }
`;

const AdminContent = styled.div`
  background: white;
  padding: 2rem;
  border-radius: 0.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  
  h2 {
    margin-bottom: 1rem;
    color: #333;
  }
  
  p {
    color: #666;
  }
`;

export default AdminPanel;
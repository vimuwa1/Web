import { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import styled from 'styled-components';

const Dashboard = () => {
  const { user, logout } = useContext(AuthContext);

  return (
    <DashboardContainer>
      <Header>
        <h1>Welcome, {user?.name}</h1>
        <LogoutButton onClick={logout}>Logout</LogoutButton>
      </Header>
      
      <DashboardGrid>
        <Card>
          <h3>Recent Orders</h3>
          <p>No recent orders</p>
        </Card>
        <Card>
          <h3>Wishlist</h3>
          <p>Your wishlist is empty</p>
        </Card>
        <Card>
          <h3>Account Details</h3>
          <p>Email: {user?.email}</p>
        </Card>
      </DashboardGrid>
    </DashboardContainer>
  );
};

const DashboardContainer = styled.div`
  padding: 2rem;
  max-width: 1200px;
  margin: 0 auto;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 2rem;
  
  h1 {
    font-size: 1.75rem;
    color: #333;
  }
`;

const LogoutButton = styled.button`
  padding: 0.5rem 1rem;
  background: #ef4444;
  color: white;
  border: none;
  border-radius: 0.25rem;
  cursor: pointer;
  
  &:hover {
    background: #dc2626;
  }
`;

const DashboardGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 1.5rem;
`;

const Card = styled.div`
  background: white;
  padding: 1.5rem;
  border-radius: 0.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  
  h3 {
    margin-bottom: 1rem;
    color: #333;
  }
  
  p {
    color: #666;
  }
`;

export default Dashboard;
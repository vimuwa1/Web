import { motion } from 'framer-motion';
import LetsGo from '../components/LetsGo';
import ProductGrid from '../components/ProductGrid';
import products from '../data/products';
import styled from 'styled-components';

const Home = () => {
  const featuredProducts = products.slice(0, 8); // Show first 8 products as featured

  return (
    <HomeContainer>
      <LetsGo />
      
      <FeaturedSection>
        <SectionTitle>Featured Products</SectionTitle>
        <ProductGrid products={featuredProducts} />
        <ViewAllLink href="/products">View All Products →</ViewAllLink>
      </FeaturedSection>
      
      <CategoriesSection>
        <SectionTitle>Shop by Category</SectionTitle>
        <CategoryGrid>
          <CategoryCard
            as={motion.div}
            whileHover={{ scale: 1.03 }}
          >
            <CategoryImage src="https://images.unsplash.com/photo-1523275335684-37898b6baf30" />
            <CategoryName>Electronics</CategoryName>
          </CategoryCard>
          <CategoryCard
            as={motion.div}
            whileHover={{ scale: 1.03 }}
          >
            <CategoryImage src="https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9" />
            <CategoryName>Fashion</CategoryName>
          </CategoryCard>
          <CategoryCard
            as={motion.div}
            whileHover={{ scale: 1.03 }}
          >
            <CategoryImage src="https://images.unsplash.com/photo-1556228453-efd6c1ff04f6" />
            <CategoryName>Home & Garden</CategoryName>
          </CategoryCard>
          <CategoryCard
            as={motion.div}
            whileHover={{ scale: 1.03 }}
          >
            <CategoryImage src="https://images.unsplash.com/photo-1545205597-3d9d02c29597" />
            <CategoryName>Fitness</CategoryName>
          </CategoryCard>
        </CategoryGrid>
      </CategoriesSection>
    </HomeContainer>
  );
};

const HomeContainer = styled.div`
  padding-bottom: 3rem;
`;

const FeaturedSection = styled.section`
  padding: 3rem 1rem;
  max-width: 1200px;
  margin: 0 auto;
`;

const SectionTitle = styled.h2`
  font-size: 2rem;
  text-align: center;
  margin-bottom: 2rem;
  color: #1f2937;
`;

const ViewAllLink = styled.a`
  display: block;
  text-align: center;
  margin-top: 2rem;
  color: #3b82f6;
  font-weight: 600;
  text-decoration: none;
  
  &:hover {
    text-decoration: underline;
  }
`;

const CategoriesSection = styled.section`
  padding: 3rem 1rem;
  background: #f9fafb;
`;

const CategoryGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  max-width: 1200px;
  margin: 0 auto;
`;

const CategoryCard = styled.div`
  background: white;
  border-radius: 0.5rem;
  overflow: hidden;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  cursor: pointer;
`;

const CategoryImage = styled.img`
  width: 100%;
  height: 200px;
  object-fit: cover;
`;

const CategoryName = styled.h3`
  padding: 1rem;
  text-align: center;
  color: #1f2937;
`;

export default Home;
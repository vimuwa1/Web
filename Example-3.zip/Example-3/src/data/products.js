const products = [
  {
    id: 1,
    name: "Wireless Bluetooth Earbuds",
    price: 59.99,
    description: "High-quality wireless earbuds with noise cancellation",
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df",
    rating: 4.5,
    reviews: 128,
    stock: 50,
    colors: ["Black", "White", "Blue"],
    features: [
      "Active Noise Cancellation",
      "20hrs battery life",
      "IPX7 waterproof"
    ]
  },
  {
    id: 2,
    name: "Smart Watch Pro",
    price: 129.99,
    description: "Fitness tracker with heart rate monitor",
    category: "Electronics",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30",
    rating: 4.7,
    reviews: 215,
    stock: 35,
    colors: ["Black", "Silver", "Rose Gold"],
    features: [
      "Heart rate monitor",
      "Sleep tracking",
      "Water resistant"
    ]
  },
  {
    id: 3,
    name: "Organic Cotton T-Shirt",
    price: 24.99,
    description: "Comfortable eco-friendly cotton t-shirt",
    category: "Fashion",
    image: "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9",
    rating: 4.3,
    reviews: 89,
    stock: 120,
    colors: ["White", "Black", "Gray", "Navy"],
    sizes: ["S", "M", "L", "XL"]
  },
  // Add 27 more products following the same structure
  // ...
  {
    id: 30,
    name: "Yoga Mat",
    price: 29.99,
    description: "Non-slip premium yoga mat",
    category: "Fitness",
    image: "https://images.unsplash.com/photo-1545205597-3d9d02c29597",
    rating: 4.6,
    reviews: 156,
    stock: 45,
    colors: ["Purple", "Blue", "Green"]
  }
];

export default products;
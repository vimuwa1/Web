import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaShoppingCart, FaUser, FaSearch, FaHeart } from 'react-icons/fa';
import { motion } from 'framer-motion';
import { useCart } from '../context/CartContext';
import styled from 'styled-components';
import SearchBar from './SearchBar';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { cartItems } = useCart();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      window.scrollY > 50 ? setIsScrolled(true) : setIsScrolled(false);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <NavbarContainer $isScrolled={isScrolled}>
      <NavContent>
        <Logo to="/">TrendifyStore</Logo>
        
        <NavLinks $isMobileOpen={isMobileMenuOpen}>
          <NavLink to="/products">Shop</NavLink>
          <NavLink to="/deals">Deals</NavLink>
          <NavLink to="/about">About</NavLink>
          <SearchBar />
        </NavLinks>
        
        <NavIcons>
          <IconLink to="/account"><FaUser /></IconLink>
          <IconLink to="/wishlist"><FaHeart /></IconLink>
          <CartLink to="/cart">
            <FaShoppingCart />
            {cartItems.length > 0 && (
              <CartCount 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                key={cartItems.length}
              >
                {cartItems.reduce((total, item) => total + item.quantity, 0)}
              </CartCount>
            )}
          </CartLink>
          <Hamburger onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            <span></span>
            <span></span>
            <span></span>
          </Hamburger>
        </NavIcons>
      </NavContent>
    </NavbarContainer>
  );
};

const NavbarContainer = styled.nav`
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 1000;
  background: ${props => props.$isScrolled ? 'rgba(255, 255, 255, 0.95)' : 'rgba(255, 255, 255, 0.9)'};
  box-shadow: ${props => props.$isScrolled ? '0 2px 10px rgba(0, 0, 0, 0.1)' : 'none'};
  transition: all 0.3s ease;
`;

const NavContent = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 1rem 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

const Logo = styled(Link)`
  font-size: 1.8rem;
  font-weight: 700;
  color: #333;
  text-decoration: none;
  span {
    color: #3b82f6;
  }
`;

const NavLinks = styled.div`
  display: flex;
  align-items: center;
  gap: 2rem;

  @media (max-width: 768px) {
    position: fixed;
    top: 70px;
    left: 0;
    width: 100%;
    background: white;
    flex-direction: column;
    align-items: flex-start;
    padding: 2rem;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    transform: translateY(${props => props.$isMobileOpen ? '0' : '-150%'});
    transition: transform 0.3s ease;
    z-index: 999;
  }
`;

const NavLink = styled(Link)`
  color: #333;
  text-decoration: none;
  font-weight: 500;
  transition: color 0.3s;
  &:hover {
    color: #3b82f6;
  }
`;

const NavIcons = styled.div`
  display: flex;
  align-items: center;
  gap: 1.5rem;
`;

const IconLink = styled(Link)`
  color: #333;
  font-size: 1.2rem;
  transition: color 0.3s;
  &:hover {
    color: #3b82f6;
  }
`;

const CartLink = styled(Link)`
  position: relative;
  color: #333;
  font-size: 1.2rem;
  transition: color 0.3s;
  &:hover {
    color: #3b82f6;
  }
`;

const CartCount = styled(motion.span)`
  position: absolute;
  top: -10px;
  right: -10px;
  background: #3b82f6;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.7rem;
  font-weight: bold;
`;

const Hamburger = styled.div`
  display: none;
  flex-direction: column;
  justify-content: space-between;
  width: 24px;
  height: 18px;
  cursor: pointer;

  span {
    display: block;
    width: 100%;
    height: 2px;
    background: #333;
    transition: all 0.3s;
  }

  @media (max-width: 768px) {
    display: flex;
  }
`;

export default Navbar;
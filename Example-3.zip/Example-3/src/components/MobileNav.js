import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const MobileNav = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Background $isOpen={isOpen}>
        <MenuIcon onClick={() => setIsOpen(!isOpen)}>
          <span></span>
          <span></span>
          <span></span>
        </MenuIcon>
      </Background>
      
      <MobileMenu $isOpen={isOpen}>
        <NavLink to="/" onClick={() => setIsOpen(false)}>Home</NavLink>
        <NavLink to="/products" onClick={() => setIsOpen(false)}>Products</NavLink>
        <NavLink to="/cart" onClick={() => setIsOpen(false)}>Cart</NavLink>
        <NavLink to="/account" onClick={() => setIsOpen(false)}>Account</NavLink>
      </MobileMenu>
    </>
  );
};

const Background = styled.div`
  border-radius: 1rem;
  border: 1px solid #1a1a1a;
  background: rgba(74, 74, 74, 0.39);
  mix-blend-mode: luminosity;
  box-shadow: 0px 0px 0px 1px rgba(0, 0, 0, 0.2);
  backdrop-filter: blur(15px);
  width: 4rem;
  height: 4rem;
  display: flex;
  justify-content: center;
  align-items: center;
  position: fixed;
  bottom: 2rem;
  right: 2rem;
  z-index: 1000;
  display: none;
  
  @media (max-width: 768px) {
    display: flex;
  }
`;

const MenuIcon = styled.button`
  width: 1.75rem;
  height: 1.75rem;
  padding: 0.1875rem;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  align-items: center;
  background: none;
  border: none;
  cursor: pointer;
  
  span {
    width: 100%;
    height: 0.125rem;
    border-radius: 0.125rem;
    background-color: rgb(0, 122, 255);
    box-shadow: 0 0.5px 2px 0 hsla(0, 0%, 0%, 0.2);
    transition: transform 0.4s, background-color 0.4s, width 0.4s, opacity 0.4s;
    
    &:nth-child(2) {
      width: 60%;
    }
  }
  
  &:hover span:nth-child(1) {
    background-color: rgb(255, 59, 48);
    transform: translateY(7.5px) rotate(-45deg);
  }
  
  &:hover span:nth-child(2) {
    width: 0;
    opacity: 0;
  }
  
  &:hover span:nth-child(3) {
    background-color: rgb(255, 59, 48);
    transform: translateY(-7.5px) rotate(45deg);
  }
`;

const MobileMenu = styled.div`
  position: fixed;
  bottom: ${props => props.$isOpen ? '7rem' : '-100%'};
  right: 2rem;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 1rem;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  z-index: 999;
  transition: bottom 0.3s ease;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(0, 0, 0, 0.1);
`;

const NavLink = styled(Link)`
  padding: 0.75rem 1.5rem;
  border-radius: 0.5rem;
  text-decoration: none;
  color: #333;
  font-weight: 500;
  transition: all 0.2s ease;
  
  &:hover {
    background-color: #f3f4f6;
    color: #3b82f6;
  }
`;

export default MobileNav;
import { useState } from 'react';
import styled from 'styled-components';

const CheckoutForm = () => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    address: '',
    city: '',
    country: '',
    paymentMethod: 'credit-card'
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission
  };

  return (
    <FormContainer onSubmit={handleSubmit}>
      <FormSection>
        <h3>Shipping Information</h3>
        <FormRow>
          <FormGroup>
            <label>First Name</label>
            <input 
              type="text" 
              name="firstName" 
              value={formData.firstName} 
              onChange={handleChange} 
              required 
            />
          </FormGroup>
          <FormGroup>
            <label>Last Name</label>
            <input 
              type="text" 
              name="lastName" 
              value={formData.lastName} 
              onChange={handleChange} 
              required 
            />
          </FormGroup>
        </FormRow>
        
        <FormGroup>
          <label>Email</label>
          <input 
            type="email" 
            name="email" 
            value={formData.email} 
            onChange={handleChange} 
            required 
          />
        </FormGroup>
        
        <FormGroup>
          <label>Address</label>
          <input 
            type="text" 
            name="address" 
            value={formData.address} 
            onChange={handleChange} 
            required 
          />
        </FormGroup>
        
        <FormRow>
          <FormGroup>
            <label>City</label>
            <input 
              type="text" 
              name="city" 
              value={formData.city} 
              onChange={handleChange} 
              required 
            />
          </FormGroup>
          <FormGroup>
            <label>Country</label>
            <select 
              name="country" 
              value={formData.country} 
              onChange={handleChange} 
              required
            >
              <option value="">Select Country</option>
              <option value="US">United States</option>
              <option value="UK">United Kingdom</option>
              {/* Add more countries */}
            </select>
          </FormGroup>
        </FormRow>
      </FormSection>
      
      <FormSection>
        <h3>Payment Method</h3>
        <PaymentMethod>
          <input 
            type="radio" 
            id="credit-card" 
            name="paymentMethod" 
            value="credit-card" 
            checked={formData.paymentMethod === 'credit-card'} 
            onChange={handleChange} 
          />
          <label htmlFor="credit-card">Credit Card</label>
        </PaymentMethod>
        
        <PaymentMethod>
          <input 
            type="radio" 
            id="paypal" 
            name="paymentMethod" 
            value="paypal" 
            checked={formData.paymentMethod === 'paypal'} 
            onChange={handleChange} 
          />
          <label htmlFor="paypal">PayPal</label>
        </PaymentMethod>
      </FormSection>
      
      <SubmitButton type="submit">Place Order</SubmitButton>
    </FormContainer>
  );
};

const FormContainer = styled.form`
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
  background: white;
  border-radius: 0.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const FormSection = styled.div`
  margin-bottom: 2rem;
  
  h3 {
    font-size: 1.25rem;
    margin-bottom: 1rem;
    color: #1f2937;
  }
`;

const FormRow = styled.div`
  display: flex;
  gap: 1rem;
  
  @media (max-width: 600px) {
    flex-direction: column;
    gap: 0;
  }
`;

const FormGroup = styled.div`
  flex: 1;
  margin-bottom: 1rem;
  
  label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: #4b5563;
  }
  
  input, select {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #d1d5db;
    border-radius: 0.25rem;
    font-size: 1rem;
    
    &:focus {
      outline: none;
      border-color: #3b82f6;
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
    }
  }
`;

const PaymentMethod = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 0.5rem;
  
  input {
    margin-right: 0.5rem;
  }
  
  label {
    font-weight: 500;
  }
`;

const SubmitButton = styled.button`
  width: 100%;
  padding: 1rem;
  background: #10b981;
  color: white;
  border: none;
  border-radius: 0.25rem;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  
  &:hover {
    background: #059669;
  }
`;

export default CheckoutForm;
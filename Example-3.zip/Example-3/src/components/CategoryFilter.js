import { Link } from 'react-router-dom';
import styled from 'styled-components';

const categories = [
  { name: 'All', path: '/products' },
  { name: 'Electronics', path: '/products?category=electronics' },
  { name: 'Fashion', path: '/products?category=fashion' },
  { name: 'Home', path: '/products?category=home' },
  { name: 'Fitness', path: '/products?category=fitness' },
];

const CategoryFilter = () => {
  return (
    <CategoryContainer>
      {categories.map(category => (
        <CategoryLink 
          key={category.name} 
          to={category.path}
        >
          {category.name}
        </CategoryLink>
      ))}
    </CategoryContainer>
  );
};

const CategoryContainer = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
  overflow-x: auto;
  padding-bottom: 0.5rem;
  
  &::-webkit-scrollbar {
    height: 5px;
  }
  
  &::-webkit-scrollbar-thumb {
    background: #ddd;
    border-radius: 2.5px;
  }
`;

const CategoryLink = styled(Link)`
  padding: 0.5rem 1rem;
  background: white;
  border-radius: 2rem;
  text-decoration: none;
  color: #4b5563;
  font-weight: 500;
  white-space: nowrap;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  transition: all 0.2s ease;
  
  &:hover {
    background: #3b82f6;
    color: white;
  }
`;

export default CategoryFilter;
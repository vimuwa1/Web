import { useCart } from '../context/CartContext';
import styled from 'styled-components';

const OrderSummary = () => {
  const { cartItems, cartTotal } = useCart();

  return (
    <SummaryContainer>
      <h3>Order Summary</h3>
      
      <ItemsList>
        {cartItems.map(item => (
          <Item key={item.id}>
            <ItemImage src={item.image} alt={item.name} />
            <ItemDetails>
              <ItemName>{item.name}</ItemName>
              <ItemPrice>${item.price.toFixed(2)} x {item.quantity}</ItemPrice>
            </ItemDetails>
            <ItemTotal>${(item.price * item.quantity).toFixed(2)}</ItemTotal>
          </Item>
        ))}
      </ItemsList>
      
      <SummaryTotal>
        <SummaryRow>
          <span>Subtotal</span>
          <span>${cartTotal.toFixed(2)}</span>
        </SummaryRow>
        <SummaryRow>
          <span>Shipping</span>
          <span>Free</span>
        </SummaryRow>
        <SummaryRow>
          <span>Tax</span>
          <span>$0.00</span>
        </SummaryRow>
        <SummaryRow total>
          <span>Total</span>
          <span>${cartTotal.toFixed(2)}</span>
        </SummaryRow>
      </SummaryTotal>
    </SummaryContainer>
  );
};

const SummaryContainer = styled.div`
  background: white;
  padding: 1.5rem;
  border-radius: 0.5rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  
  h3 {
    font-size: 1.25rem;
    margin-bottom: 1.5rem;
    color: #1f2937;
  }
`;

const ItemsList = styled.div`
  margin-bottom: 1.5rem;
`;

const Item = styled.div`
  display: flex;
  align-items: center;
  margin-bottom: 1rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid #f3f4f6;
`;

const ItemImage = styled.img`
  width: 60px;
  height: 60px;
  object-fit: cover;
  border-radius: 0.25rem;
  margin-right: 1rem;
`;

const ItemDetails = styled.div`
  flex-grow: 1;
`;

const ItemName = styled.div`
  font-weight: 500;
  margin-bottom: 0.25rem;
`;

const ItemPrice = styled.div`
  color: #6b7280;
  font-size: 0.875rem;
`;

const ItemTotal = styled.div`
  font-weight: 600;
`;

const SummaryTotal = styled.div`
  border-top: 1px solid #e5e7eb;
  padding-top: 1rem;
`;

const SummaryRow = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 0.5rem;
  font-weight: ${props => props.total ? '600' : 'normal'};
  font-size: ${props => props.total ? '1.1rem' : '1rem'};
`;

export default OrderSummary;
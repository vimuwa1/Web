import { ToastContainer } from 'react-toastify';
import styled from 'styled-components';

const Toast = () => {
  return (
    <StyledToastContainer
      position="bottom-right"
      autoClose={3000}
      hideProgressBar
      newestOnTop
      closeOnClick
      rtl={false}
      pauseOnFocusLoss
      draggable
      pauseOnHover
    />
  );
};

const StyledToastContainer = styled(ToastContainer)`
  .Toastify__toast {
    border-radius: 0.5rem;
    padding: 1rem;
    color: white;
    font-weight: 500;
  }
  
  .Toastify__toast--success {
    background: #10b981;
  }
  
  .Toastify__toast--error {
    background: #ef4444;
  }
  
  .Toastify__toast--info {
    background: #3b82f6;
  }
`;

export default Toast;
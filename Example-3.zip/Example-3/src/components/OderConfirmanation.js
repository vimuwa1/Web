import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const OrderConfirmation = ({ orderId }) => {
  return (
    <ConfirmationContainer
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <ConfirmationIcon>✓</ConfirmationIcon>
      <ConfirmationTitle>Order Confirmed!</ConfirmationTitle>
      <ConfirmationText>
        Thank you for your purchase. Your order number is <strong>{orderId}</strong>.
        We've sent a confirmation email with your order details.
      </ConfirmationText>
      <ContinueShopping to="/products">Continue Shopping</ContinueShopping>
    </ConfirmationContainer>
  );
};

const ConfirmationContainer = styled(motion.div)`
  text-align: center;
  padding: 3rem 1rem;
  max-width: 600px;
  margin: 0 auto;
`;

const ConfirmationIcon = styled.div`
  width: 80px;
  height: 80px;
  background: #10b981;
  color: white;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 2.5rem;
  margin: 0 auto 1.5rem;
`;

const ConfirmationTitle = styled.h2`
  font-size: 2rem;
  margin-bottom: 1rem;
  color: #1f2937;
`;

const ConfirmationText = styled.p`
  color: #6b7280;
  line-height: 1.6;
  margin-bottom: 2rem;
`;

const ContinueShopping = styled(Link)`
  display: inline-block;
  padding: 0.75rem 1.5rem;
  background: #3b82f6;
  color: white;
  border-radius: 0.25rem;
  text-decoration: none;
  font-weight: 600;
  
  &:hover {
    background: #2563eb;
  }
`;

export default OrderConfirmation;
import styled from 'styled-components';

const ResponsiveImage = ({ src, alt, ...props }) => {
  return (
    <ImageContainer>
      <Image 
        src={src} 
        alt={alt} 
        loading="lazy"
        {...props}
      />
    </ImageContainer>
  );
};

const ImageContainer = styled.div`
  position: relative;
  width: 100%;
  padding-top: 100%; /* 1:1 Aspect Ratio */
  overflow: hidden;
`;

const Image = styled.img`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
`;

export default ResponsiveImage;
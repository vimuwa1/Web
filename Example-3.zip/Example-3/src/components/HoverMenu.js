import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const HoverMenu = () => {
  return (
    <MenuContainer>
      <MenuTitle>TrendifyStore Menu</MenuTitle>
      <MenuItems>
        <MenuItem>
          <Link to="/">
            <IconContainer>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M9 22V12H15V22M3 9L12 2L21 9V20C21 20.5304 20.7893 21.0391 20.4142 21.4142C20.0391 21.7893 19.5304 22 19 22H5C4.46957 22 3.96086 21.7893 3.58579 21.4142C3.21071 21.0391 3 20.5304 3 20V9Z" stroke="currentColor" strokeWidth="2"></path>
              </svg>
            </IconContainer>
            <Tooltip>Home</Tooltip>
          </Link>
        </MenuItem>
        
        <MenuItem>
          <Link to="/products">
            <IconContainer>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 11.5C21.0034 12.8199 20.6951 14.1219 20.1 15.3C19.3944 16.7118 18.3098 17.8992 16.9674 18.7293C15.6251 19.5594 14.0782 19.9994 12.5 20C11.1801 20.0035 9.87812 19.6951 8.7 19.1L3 21L4.9 15.3C4.30493 14.1219 3.99656 12.8199 4 11.5C4.00061 9.92179 4.44061 8.37488 5.27072 7.03258C6.10083 5.69028 7.28825 4.6056 8.7 3.90003C9.87812 3.30496 11.1801 2.99659 12.5 3.00003H13C15.0843 3.11502 17.053 3.99479 18.5291 5.47089C20.0052 6.94699 20.885 8.91568 21 11V11.5Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round"></path>
              </svg>
            </IconContainer>
            <Tooltip>Products</Tooltip>
          </Link>
        </MenuItem>
        
        <MenuItem>
          <Link to="/cart">
            <IconContainer>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
              </svg>
            </IconContainer>
            <Tooltip>Cart</Tooltip>
          </Link>
        </MenuItem>
        
        <MenuItem>
          <Link to="/account">
            <IconContainer>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path>
              </svg>
            </IconContainer>
            <Tooltip>Account</Tooltip>
          </Link>
        </MenuItem>
      </MenuItems>
    </MenuContainer>
  );
};

const MenuContainer = styled.div`
  flex-direction: column;
  align-items: center;
  padding: 1.5rem;
  background: linear-gradient(to bottom right, #f8fafc, #f1f5f9);
  border-radius: 0.75rem;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
`;

const MenuTitle = styled.div`
  text-align: center;
  margin-bottom: 1.5rem;
  background: linear-gradient(to right, #3b82f6, #8b5cf6, #ec4899);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  font-size: 1.875rem;
  font-weight: 800;
  letter-spacing: -0.025em;
`;

const MenuItems = styled.div`
  border: 1px solid rgba(229, 231, 235, 0.8);
  padding: 0.75rem 0.5rem;
  display: flex;
  gap: 0.5rem;
  border-radius: 0.75rem;
  background: rgba(255, 255, 255, 0.8);
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  backdrop-filter: blur(4px);
  transition: all 0.3s ease;
  
  &:hover {
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  }
`;

const MenuItem = styled.div`
  position: relative;
  padding: 0 0.75rem;
  cursor: pointer;
  
  a {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-decoration: none;
    color: inherit;
  }
`;

const IconContainer = styled.div`
  display: flex;
  height: 2.5rem;
  width: 2.5rem;
  align-items: center;
  justify-content: center;
  border-radius: 0.5rem;
  color: #374151;
  transition: all 0.3s ease;
  
  ${MenuItem}:hover & {
    background-color: #eff6ff;
    color: #2563eb;
    transform: scale(1.1);
  }
  
  svg {
    width: 1.25rem;
    height: 1.25rem;
  }
`;

const Tooltip = styled.span`
  position: absolute;
  top: -3rem;
  left: 50%;
  transform: translateX(-50%) scale(0);
  transform-origin: bottom;
  padding: 0.375rem 0.75rem;
  border-radius: 0.375rem;
  border: 1px solid #e5e7eb;
  background-color: white;
  font-size: 0.75rem;
  font-weight: 500;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  transition: all 0.3s ease;
  z-index: 20;
  
  ${MenuItem}:hover & {
    transform: translateX(-50%) scale(1);
  }
  
  &::before {
    content: '';
    position: absolute;
    bottom: -5px;
    left: 50%;
    transform: translateX(-50%);
    border-width: 6px;
    border-style: solid;
    border-color: white transparent transparent transparent;
  }
`;

export default HoverMenu;
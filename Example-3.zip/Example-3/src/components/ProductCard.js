import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import styled from 'styled-components';

const ProductCard = ({ product }) => {
  return (
    <CardContainer
      as={motion.div}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      whileHover={{ y: -5 }}
    >
      <ProductLink to={`/products/${product.id}`}>
        <ImageContainer>
          <ProductImage 
            src={`${product.image}?w=400&h=400&auto=format&fit=crop`} 
            alt={product.name}
            loading="lazy"
          />
          <Overlay>
            <QuickView>Quick View</QuickView>
          </Overlay>
        </ImageContainer>
        <ProductInfo>
          <ProductName>{product.name}</ProductName>
          <ProductCategory>{product.category}</ProductCategory>
          <ProductPrice>${product.price.toFixed(2)}</ProductPrice>
          <Rating>
            {[...Array(5)].map((_, i) => (
              <Star key={i} filled={i < Math.floor(product.rating)}>
                ★
              </Star>
            ))}
            <ReviewCount>({product.reviews})</ReviewCount>
          </Rating>
        </ProductInfo>
      </ProductLink>
      <AddToCartButton
        as={motion.button}
        whileTap={{ scale: 0.95 }}
      >
        Add to Cart
      </AddToCartButton>
    </CardContainer>
  );
};

const CardContainer = styled.div`
  background: white;
  border-radius: 0.5rem;
  overflow: hidden;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
`;

const ProductLink = styled(Link)`
  text-decoration: none;
  color: inherit;
`;

const ImageContainer = styled.div`
  position: relative;
  padding-top: 100%;
  overflow: hidden;
`;

const ProductImage = styled.img`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
  
  ${CardContainer}:hover & {
    transform: scale(1.05);
  }
`;

const Overlay = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.3);
  display: flex;
  align-items: center;
  justify-content: center;
  opacity: 0;
  transition: opacity 0.3s ease;
  
  ${CardContainer}:hover & {
    opacity: 1;
  }
`;

const QuickView = styled.span`
  color: white;
  background: rgba(0, 0, 0, 0.7);
  padding: 0.5rem 1rem;
  border-radius: 2rem;
  font-size: 0.875rem;
  font-weight: 500;
`;

const ProductInfo = styled.div`
  padding: 1rem;
  flex-grow: 1;
`;

const ProductName = styled.h3`
  font-size: 1rem;
  font-weight: 600;
  margin-bottom: 0.25rem;
`;

const ProductCategory = styled.p`
  color: #6b7280;
  font-size: 0.75rem;
  margin-bottom: 0.5rem;
`;

const ProductPrice = styled.p`
  font-weight: 700;
  color: #1f2937;
  margin-bottom: 0.5rem;
`;

const Rating = styled.div`
  display: flex;
  align-items: center;
  margin-top: auto;
`;

const Star = styled.span`
  color: ${props => props.filled ? '#f59e0b' : '#d1d5db'};
  font-size: 0.875rem;
`;

const ReviewCount = styled.span`
  color: #6b7280;
  font-size: 0.75rem;
  margin-left: 0.25rem;
`;

const AddToCartButton = styled.button`
  background: #3b82f6;
  color: white;
  border: none;
  padding: 0.75rem;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.3s ease;
  margin-top: auto;
  
  &:hover {
    background: #2563eb;
  }
`;

export default ProductCard;
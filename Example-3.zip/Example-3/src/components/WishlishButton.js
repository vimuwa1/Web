import { useState } from 'react';
import styled from 'styled-components';

const WishlistButton = ({ productId }) => {
  const [isWishlisted, setIsWishlisted] = useState(false);

  const toggleWishlist = () => {
    setIsWishlisted(!isWishlisted);
    // In a real app, you would update the wishlist in your state management
  };

  return (
    <WishlistButtonStyled 
      onClick={toggleWishlist}
      aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
    >
      <HeartIcon filled={isWishlisted}>
        ♥
      </HeartIcon>
    </WishlistButtonStyled>
  );
};

const WishlistButtonStyled = styled.button`
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: white;
  border: none;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  z-index: 10;
`;

const HeartIcon = styled.span`
  color: ${props => props.filled ? '#ef4444' : '#d1d5db'};
  font-size: 1.25rem;
`;

export default WishlistButton;
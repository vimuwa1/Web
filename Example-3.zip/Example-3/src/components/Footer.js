import styled from 'styled-components';

const Footer = () => {
  return (
    <FooterContainer>
      <FooterContent>
        <FooterSection>
          <h3>TrendifyStore</h3>
          <p>The latest trends at your fingertips</p>
        </FooterSection>
        
        <FooterSection>
          <h4>Quick Links</h4>
          <FooterLink href="/">Home</FooterLink>
          <FooterLink href="/products">Products</FooterLink>
          <FooterLink href="/about">About Us</FooterLink>
          <FooterLink href="/contact">Contact</FooterLink>
        </FooterSection>
        
        <FooterSection>
          <h4>Customer Service</h4>
          <FooterLink href="/faq">FAQ</FooterLink>
          <FooterLink href="/shipping">Shipping Policy</FooterLink>
          <FooterLink href="/returns">Returns & Exchanges</FooterLink>
          <FooterLink href="/privacy">Privacy Policy</FooterLink>
        </FooterSection>
        
        <FooterSection>
          <h4>Connect With Us</h4>
          <SocialLinks>
            <SocialLink href="#"><i className="fab fa-facebook"></i></SocialLink>
            <SocialLink href="#"><i className="fab fa-twitter"></i></SocialLink>
            <SocialLink href="#"><i className="fab fa-instagram"></i></SocialLink>
            <SocialLink href="#"><i className="fab fa-pinterest"></i></SocialLink>
          </SocialLinks>
          <NewsletterForm>
            <input type="email" placeholder="Your email address" />
            <button type="submit">Subscribe</button>
          </NewsletterForm>
        </FooterSection>
      </FooterContent>
      
      <Copyright>
        &copy; {new Date().getFullYear()} TrendifyStore. All rights reserved.
      </Copyright>
    </FooterContainer>
  );
};

const FooterContainer = styled.footer`
  background: #1f2937;
  color: white;
  padding: 3rem 0 1rem;
  margin-top: auto;
`;

const FooterContent = styled.div`
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
`;

const FooterSection = styled.div`
  h3, h4 {
    margin-bottom: 1rem;
    color: white;
  }
  
  p {
    color: #9ca3af;
    line-height: 1.6;
  }
`;

const FooterLink = styled.a`
  display: block;
  color: #9ca3af;
  margin-bottom: 0.5rem;
  text-decoration: none;
  
  &:hover {
    color: white;
  }
`;

const SocialLinks = styled.div`
  display: flex;
  gap: 1rem;
  margin-bottom: 1rem;
`;

const SocialLink = styled.a`
  color: white;
  font-size: 1.25rem;
  
  &:hover {
    color: #3b82f6;
  }
`;

const NewsletterForm = styled.form`
  display: flex;
  
  input {
    flex-grow: 1;
    padding: 0.5rem;
    border: none;
    border-radius: 0.25rem 0 0 0.25rem;
  }
  
  button {
    padding: 0.5rem 1rem;
    background: #3b82f6;
    color: white;
    border: none;
    border-radius: 0 0.25rem 0.25rem 0;
    cursor: pointer;
    
    &:hover {
      background: #2563eb;
    }
  }
`;

const Copyright = styled.div`
  text-align: center;
  padding-top: 2rem;
  margin-top: 2rem;
  border-top: 1px solid #374151;
  color: #9ca3af;
  font-size: 0.875rem;
`;

export default Footer;
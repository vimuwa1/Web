import ProductCard from './ProductCard';
import styled from 'styled-components';

const ProductGrid = ({ products }) => {
  return (
    <GridContainer>
      {products.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
    </GridContainer>
  );
};

const GridContainer = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 2rem;
`;

export default ProductGrid;